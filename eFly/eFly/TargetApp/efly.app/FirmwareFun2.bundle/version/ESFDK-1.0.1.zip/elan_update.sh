#!/bin/sh

echo "elanview added, do this .sh after ota update"

rm /netPrivate/param
sync
blockdev --flushbufs /dev/mtdblock5
